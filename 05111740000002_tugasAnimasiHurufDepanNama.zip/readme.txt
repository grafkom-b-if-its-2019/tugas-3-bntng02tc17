Tugas ini dibuat dengan memakai bahan:
tutorial transformasi segitiga Pak Hadziq
